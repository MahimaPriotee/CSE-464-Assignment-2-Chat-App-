package com.example.chat_application_iub_cse464

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
